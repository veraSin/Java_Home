package com.company;

public class Road {
    private int len;

    public Road(int len) {
        this.len = len;
    }

    public int getLen() {
        return len;
    }
}
