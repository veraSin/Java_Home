package com.company;

public class Wall {
    private int h;

    public Wall(int h) {
        this.h = h;
    }

    public int getH() {
        return h;
    }
}
